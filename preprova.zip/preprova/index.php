/*
Gustavo Melo
Pedro Rafaell
Eduardo Henrique
Lucas de Freitas
Renato Batista
*/

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="crud.php" method="POST">
        <label for="">Tipo do imovel</label>
        <select name="imovel" id="imovel">
            <option value="" selected disabled>Escolha:</option>
            <option value="casa">casa</option>
            <option value="apartamento">apartamento</option>
            <option value="condominio">condominio</option>
        </select>
        <br>
        <label for="valor" >Valor:</label>
        <input type="number"name="valor" id="valor">
        <label for="tipo">tipo de operação:</label>
        <select name="operacao" id="operacao">
            <option value="" selected disabled>Escolha:</option>
            <option value="venda">venda</option>
            <option value="locação">locação</option>
        </select>
        <p>Dados do proprietario:</p>
        <label for="proprietario">Nome</label>
        <input type="text" name="proprietario" id="proprietario">
        <label for="telefoneP">telefone</label>
        <input type="tel" name="telefoneP" id="telefoneP">
        <p>Dados do corretor:</p>
        <label for="corretor">corretor</label>
        <select name="corretor" id="corretor">
            <option value="" selected disabled>Escolha:</option>
            <option value="Ricardo">Ricardo</option>
            <option value="Gertrudes">Gertrudes</option>
        </select>
        <label for="telefone-corretor">telefone corretor</label>
        <input type="tel"name="telefoneC"id="telefoneC">
        <input type="submit" value="Enviar">



    </form>
</body>
</html>

<?php
    $conexao = mysqli_connect("localhost:3007", "root", "", "imobiliaria");

?>
<?php
$imovel = $_REQUEST['imovel'];
$valor = $_REQUEST['valor'];
$operacao = $_REQUEST['operacao'];
$proprietario = $_REQUEST['proprietario'];
$telefoneP = $_REQUEST['telefoneP'];
$corretor = $_REQUEST['corretor'];
$telefoneC = $_REQUEST['telefoneC'];

include 'conexao.php';

mysqli_query($conexao, "INSERT INTO `clientes`(`Tipo de imovel`, `valor do imovel`, `operação`, `nome proprietario`, `telefone proprietario`, `nome corretor`, `telefone corretor`) VALUES 
('$imovel','$valor','$operacao','$proprietario','$telefoneP','$corretor','$telefoneC')");

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
<button href="editarForm.php">Editar</button>

  <button>Excluir</button>
</body>
</html>


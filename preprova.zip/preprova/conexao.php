<?php
    $conexao = mysqli_connect("localhost:3007", "root", "", "imobiliaria");

?>
